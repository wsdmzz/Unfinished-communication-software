#ifndef _INSERT_H
#define _INSERT_H

#include "sqlite3.h"

//注册用户
int insert_usr(char *usr_id,char *admin,char *nick_name,char *phone,sqlite3 *db);

//添加好友
int insert_friend(char *from_id,char *to_id,char *nickname,char *time,sqlite3 *db);


//添加好友聊天记录表信息
int insert_h_chat(char *f_id,char *t_id,char *buf,char *time,sqlite3 *db);

//创建群，添加群号表记录
int insert_q(char *Q_id,char *admin,sqlite3 *db);

// 添加群关系表
int insert_QQ(char *Q_id,char *id,char *nick_name,sqlite3 *db);


//添加群聊表记录
int insert_q_chat(char *Q_id,char *id,char *nick_name,char *q_buf,sqlite3 *db);

//添加单发文件表记录
int insert_d_fd(char *f_id,char *t_id,char *filename,char *time,sqlite3 *db);

// 添加群发文件记录表
int insert_q_fd(char *f_id,char *Q_id,char *filename,char *time,sqlite3 *db);
#endif
