#ifndef _FIND_H
#define _FIND_H
#include "sqlite3.h"
// 用户信息结构体
typedef struct usr 
{
	char usr_id[32];           // 账号id
	char usr_admin[32];        //密码
	char usr_name[32];    // 昵称
	char usr_phone_number[32]; //手机号
}usr_t;

// 好友表信息结构体
typedef struct friend
{
	char from_id[32];        // 用户账号
	char to_id[32];          // 其他用户账号
	char nick_name[32];      // 好友备注
	char time[32];           //加好友时间
}friend_t;

// 单聊表记录结构体
typedef struct d_chat
{
    char f_id[32];       // 聊天账号
    char t_id[32];       //对方聊天账号
    char c_buf[128];    // 聊天记录
    char time[128];
}chat_t;

//创建群号表结构体
typedef struct Q_Q_ID
{
	char Q_id[32];      //群号
	char Q_admin[32];   //群主id
}QID_t;

//群关系记录结构体
typedef struct QQ
{
    char  Q_id[32];        // 群账号
    char  id[32];          // 群成员账号
    char  nick_name[32];   //备注
}QQ_t;

// 群聊表记录结构体
typedef struct Q_chat
{
	char Q_id[32];
	char Q_number[32];
	char nick_name[128];
	char Q_buf[128];
}Q_chat_t;

// 单发文件记录结构体
typedef struct D_send
{
	char f_id[32];
	char t_id[32];     
	char fd_name[32];    //发送文件名   
	char s_time[32];    // 发送时间
}D_send_t;

//群发文件记录结构体
typedef struct Q_send
{
	char f_id[32];
	char Q_id[32];
	char fd_name[128];
	char s_time[32];
}Q_send_t;

//根据用户账号查询 用户表 中个人信息,并保存在数组arr中
/**
 * 功能：根据用户账号查询用户表中的个人信息，并保存在数组arr中
 * 参数：id  用户账号
 *       arr 数组  用于保存查询的用户信息
 *      //len  数组长度,表示可以保存信息的条数
 * 返回值： 成功返回用户记录条数，失败返回 -1
 *
 **/
int select_usr_id(char *id, usr_t *arr,sqlite3 *db);

/**
 * 功能： 无条件查询 用户表 全部信息,并保存在数组s中
 * 参数：arr 数组  用于保存查询的用户信息
 *      //len  数组长度，表示保存的信息条数
 * 返回值： 成功返回0，失败返回 -1
 **/
int select_usr(usr_t *s,sqlite3 *db);


/**
   功能： 根据自己账号和对方账号查询 好友表 个人信息, 
           判断是不是好友关系并保存在数组s 
   参数：f_id  甲方账号
         t_id   乙方账号
         s  好友数组
		 
  返回值在：成功返返回好友的个人数,查询失败返回-1
  **/
int select_friend_id(char *f_id,char *t_id,friend_t *s,sqlite3 *db);



/**
 *  功能：根据无条件查询 好友表 所有信息,并保存在数组s里面
 *  参数：s  好友数组
 *		 len  数组长度
 *  返回值在：成功返回0,失败返回-1
  **/
int select_friend(friend_t *s,sqlite3 *db);


/**
 * 功能：通过甲方和对方来查询 单聊表 记录,并保存在数组f里
 *  参数：f_id  甲方账号指针
 *        t_id  对方账号指针
 *        f 单聊表数组  用于保存单聊表信息
 *	      len 数组长度 
 *   返回值：成功返回单聊表记录个数，失败返回-1
  **/
int find_d_chat_id(char *f_id,char *t_id,chat_t *f,sqlite3 *db);

/**
 * 功能：无条件来查询 单聊表 所有记录,并保存在数组f里
 * 参数：  f 单聊表数组  用于保存单聊表信息
 *	       
 * 返回值：成功返回单聊表记录个数，失败返回-1
  **/
int find_d_chat(chat_t *f,sqlite3 *db);

/**
 *  功能：通过群成员账号来查询 群关系表 记录,并保存在数组f
 *  参数：Q_id  群号指针
 *        t_id  成员账号指针
 *        f   群关系数组，用于保存群关系表记录
 *        
 *  返回值：成功返回群关系表的记录,失败返回 -1
 **/
int find_qq_id(char *f__id,char *t_id,QQ_t *f,sqlite3 *db);

/**
 *   功能: 查询 群关系表 所有记录,保存在数组f
 *   参数：f   群关系数组，用于保存群关系表记录
 *         
 *  返回值：成功返回 群关系表的记录个数,失败返回 -1
 **/
int find_qq(QQ_t *f, sqlite3 *db);

/**
 *  功能：通过群号或者成员账号来查询 群聊表 记录,并保存在数组f
 *  参数：id  群号或者群成员账号
 *        f 群聊表记录数组， 保存群聊表记录
 *        len  数组长度
 *  返回值：成功返回0,失败返回 -1
 **/
int find_q_chat_id(char *id,Q_chat_t *f,sqlite3 *db);

/**
 *  功能：无条件来查询 群聊表所有记录,并保存在数组f
 *  参数：  f 群聊表记录数组， 保存群聊表记录
 *         db 数据库指针
 *  返回值：成功返回0,失败返回 -1
 **/
int find_q_chat(Q_chat_t *f,sqlite3 *db);


/**
 *  功能：通过群号来查询群号表记录判断是否已经创群,并保存在数组q
 *  参数：Q_id 群号指针
 *        Q_admin  指针,用于保存群主号记录
 *  返回值：成功返回群号表的群主id，失败返回NULL
 **/
char* find_q_Q_id(char *Q_id,char *Q_admin,sqlite3 *db);

/**
*  功能：通过发送方号或对方账号查询 单发文件表 记录,
*  参数：id 发送方账号或者对方账号
*        f  单发文件表数组
*       
*  返回值： 成功返回0，失败返回 -1
**/
int find_d_send(char *id,D_send_t *f,sqlite3 *db);

/**
 *  功能：通过群号或者账号查询 群发文件表记录
 *  参数：id 群号账号或者群
 */
int find_q_send(char *id,Q_send_t *f,sqlite3 *db);

//通过用户账号和密码判断用户登陆
int yan_usr(char *id,char *admin,usr_t *arr,sqlite3 *db);


/**
  功能：在群号表里，通过群号来判断有没有这个群,在群关联表里，通过群号和群成员id来判断该群有没有这个成员
 * 参数：Q_id 群号指针
 *        id  群成员指针
 *       admin  指针，保存群主id 的数据
 * 返回值：没有这个群，返回-2,没有这个成员返回-1,成功返回0
 **/
int judge_qun(char *Q_id,char *id,char *admin,QQ_t *s,sqlite3 *db);

#endif
