#ifndef _DELETE_H
#define _DELETE_H
#include "find.h"
#include "sqlite3.h"


//通过用户账号删除用户
int delete_usr(char *id,sqlite3 *db);

// 通过账号和对方账号删除好友表记录
int delete_friend(char *id,sqlite3 *db);

//通过账号或者好友账号删除好友聊天表记录
int delete_f_chat(char *id,sqlite3 *db);

// 在群关系表中通过群号和群成员账号删除群成员
int delete_qq(char *Q_id,char *id,char *admin,QQ_t *s,sqlite3 *db); 

//通过群号或者群成员账号删除群聊表记录
int delete_q_chat(char *id,sqlite3 *db);


#endif
