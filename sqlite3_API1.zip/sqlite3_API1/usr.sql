
--创建多表
--拼接创建用户记录表格式化字符串
create table usr(
                usr_id   TEXT,
                usr_admin  TEXT,
				usr_name  TEXT,
                 usr_phone_number  TEXT);

--创建好友记录表字符串
create table friend(
                  from_id  TEXT,
                  to_id    TEXT,
				  nike_name TEXT,
                  jia_time  TEXT);
-- 创建好友聊天表
create table H_chat(
                  from_id  TEXT,
                  to_id    TEXT,
                  chat_buf          TEXT,
                  chat_time     TEXT);



--创建群号表
create table q_Q_id(
						Q_id  TEXT,  --群号
                        Q_admin TEXT);  --群主id



-- 创建群关联表
create table QQ(
                  Q_id  TEXT,             --群号
                  Q_number    TEXT,     --成员id
                  Q_nick_name  TEXT);    -- 群成员备注




-- 创建群聊表
create table Q_chat(
                  Q_id  TEXT,
                  Q_number  TEXT,
				  Q_nick_name TEXT,   --群所在成员昵称
				  Q_chat_buf  TEXT);    -- 聊天记录

-- 创建单发文件表
create table D_send(
                  from_id  TEXT,
                  to_id     TEXT,
                  fd_name   TEXT,       --发送文件名
                  send_time  TEXT);  --发送时间
     
-- 创建群发文件表
create table Q_send(
                  from_id  TEXT,
                  Q_id    TEXT,
                  fd_name   TEXT,
                  send_time  TEXT);










