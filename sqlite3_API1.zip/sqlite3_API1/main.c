#include <stdio.h>
#include "find.h"
#include <string.h>
#include <time.h>
#include "insert.h"
#include <stdlib.h>
#include "judge.h"
#include "delete.h"
#include "sqlite3.h"

sqlite3 *db;

int main(int argc, char *argv[])
{
	char *dbname;

	char id[128],admin[128],name[128],phone[128];
	char t_id[32],c_buf[128],Q_id[12],nick_name[32];
	char from_id[32];
	char filename[32];
	sqlite3_stmt *stmt;
	usr_t usr_buf[128];
	int len = sizeof usr_buf;    //128
	usr_t s;
	chat_t chat_buf[128];
	friend_t f_buf[128]; 
	QQ_t  q_buf[128];
	Q_chat_t q_chat_buf[128];
	D_send_t d_send;
	Q_send_t q_send;
	QID_t q_id_buf[128];

	
	int i;
	int d = 0;
	
	if(argc != 2)
	{
		printf("用法:%s <数据库> \n",argv[0]);
		return -1;
	}
	dbname =argv[1];


	//打开数据库
	if(SQLITE_OK != sqlite3_open(dbname,&db))
	{
		printf("打开数据库失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	/*	
	//注册用户信息
	printf("请输入要注册的登陆账号");
	scanf("%s", id);
	printf("请输入要注册的登陆密码\n");
	scanf("%s", admin);
	printf("请输入要注册的昵称\n");
	scanf("%s", name);
	printf("请输入注册的用户手机号\n");
	scanf("%s",phone );
	d = Judge_usr_id(id,usr_buf);
	if(d == -1)
	{
	printf("执行预编译语句失败\n");
	goto _out;
	}
	else if(d == 1)
	{
	printf("账号已经存在,不能重新注册\n");
	goto _out;
	} 	
	if(-1 == insert_usr(id,admin,name,phone))
	{
	printf("注册用户信息失败\n");

	goto _out;
	return -1;
	}
	printf("注册用户信息成功\n");
	 */

	
/*
	// 根据账号查询用户个人信息
		printf("查询用户表信息\n");
		printf("请输入查询的用户个人账号,密码\n");
		scanf("%s %s", id,admin);	
	int ret1 =  yan_usr(id,admin,usr_buf,db);
	  if(ret1 == -2)
	  {
	  printf("用户表里没有这个账号,查询失败\n");
	  goto _out;
	  }
	  else if(ret1 == -1)
	  {
	       printf("查询失败\n");
		   goto _out;
	  }
	  else if(ret1 == 0)
	  {
	      printf("不好意思，密码不正确\n");
		  goto _out;
	  }
	  else
	  {
		 printf("登陆成功\n");
	  }
	 


	printf("==================================\n");
	for(int i = 0; i< 5;i++)
	{
		printf("%s\n",usr_buf[i].usr_id);
	}
	putchar('\n');
	*/
	/*	//   查询用户中全部信息
		if(-1 == select_usr(usr_buf,len))

		{
		printf("查询用户表失败\n");
		goto _out;
		}

		printf("执行预编译查询用户账号信息语句成功\n");
	 */
/*		
	// 跟据好友账号查询好友表个人信息,并保存在数组f_buf 中
	printf("查询好友表记录\n");
	printf("请输入甲方的账号和乙方的账号\n");
	scanf("%s %s", from_id,t_id);
	int f =  select_friend_id(from_id,t_id,f_buf);
	if(f == -1)
	{
     	printf("根据好友账号查询好友信息失败");
     	goto _out;
	}
	else if(f >0)
	{
		printf("你跟对方已是好友,不能重复添加好友\n");
		goto _out;
	}
	else
	{
		printf("对方不是你好友关系,请防诈骗\n");
	}
*/	
/*	
	//添加好友聊天表记录
	printf("请输入聊天的账号\n");
	scanf("%s", id);
	printf("请输入对方聊天的账号\n");
	scanf("%s", t_id);
	printf("请输入聊天的内容\n");
	scanf("%s", c_buf);
	if(-1 == insert_h_chat(id,t_id,c_buf,time))
	{
	printf("添加好友聊天表记录失败\n");
	goto _out;
	}
	printf("添加好友聊天记录成功\n");
*/
/*	
	//输入群号查询群号表是否已经创建群
	printf("创建群\n");
	printf("请输入群号\n");
	scanf("%s",Q_id);
	printf("请输入群主账号\n");
	scanf("%s",admin);
	char gg[23], *ret;
   	
	ret = find_q_Q_id(Q_id,gg,db);
	
	if(ret == NULL)
	{
	 	//printf("查询群失败或者没有该群\n");
		//创建群
		if(-1 ==  insert_q(Q_id,admin,db))
		{
			printf("创建群失败\n");
			goto _out;
		}
		else
		{
			printf("创建群成功,群主id是%s\n",admin);
		}
	}
	else 
	{
		printf("该群已存在,该群群主是%s\n",gg);
	     
	}




*/
/*
	// 添加群关系表记录
	printf("创建群号跟群成员关系表\n");
	printf("请输入群号\n");
	scanf("%s", Q_id);
	//fgets(Q_id,sizeof Q_id,stdin);
	printf("请输入群成员账号\n");
	//   fgets(id,sizeof id,stdin);
	scanf("%s", id);
	printf("请设置群员名称\n");
	//	fgets(nick_name,sizeof(nick_name),stdin);
	scanf("%s",nick_name);
	puts(nick_name);
	if(-1 == insert_QQ(Q_id, id,nick_name,db))
	{
	printf("添加群关系表记录失败\n");
	return -1;
	}
	printf("添加群关系表成功\n");
*/
/*
	//添加群聊表记录
	printf("添加群聊表记录\n");
	printf("请输入群号\n");
	scanf("%s", Q_id);
	printf("请输入群成员账号\n");
	scanf("%s", id);
	printf("请输入成员昵称\n");
	scanf("%s", nick_name);
	printf("请输入群聊表记录\n");
	scanf("%s", c_buf);
	if(-1 == insert_q_chat(Q_id,id,nick_name,c_buf))
	{
	printf("添加群聊表记录失败\n");
	goto _out;
	}
	printf("请输入群聊表记录成功\n");
	 */


	/*
	   printf("添加单发文件记录\n");
	   printf("请输入发送方账号,接收方账号,文件名\n");
	   scanf("%s %s %s", id,t_id,filename);

	   if(-1 == insert_d_fd(id,t_id,filename,time))
	   {
	   printf("添加单发文件表失败\n");
	   goto _out;
	   }
	   printf("添加单发文件表记录成功\n");

	   printf("请输入群发文件者账号,群号,文件名\n");
	   scanf("%s %s %s", id,Q_id,filename);
	   if(-1 == insert_q_fd(id,Q_id,filename,time))
	   {
	   printf("添加群发文件表失败\n");
	   goto _out;
	   }
	   printf("添加群发文件表记录成功\n");

	 */
		
/*	//通过账号查询聊天记录
	printf("查询单聊表记录\n");
	printf("请输入要查询的甲方账号和对方账号\n");
	scanf("%s %s", from_id,t_id);

	int f = find_d_chat_id(from_id,t_id,chat_buf);
	if(f == -1)
	{
	printf("查询单聊表记录失败\n");
	goto _out;
	}
	else if(f == 0)
	{
		printf("%s 和 %s 没有聊天记录\n",from_id,t_id);
		goto _out;
	}
	else
	{
	   printf("查询双方有%d条单聊表记录成功\n",f);
	}
		// 通过群账号或者成员账号查询群关系表记录
			printf("查询群关系表记录\n");
			printf("请输入群员账号或者成员账号\n");
			scanf("%s", id);
			if(-1 == find_qq_id(id,q_buf,len))
			{
			printf("查询群关系表记录失败\n");
			goto _out;
			}
			printf("预编译查询群关系表记录语句成功\n");


	// 通过群号或者成员账号查询群聊表记录
	printf("查询群聊表记录\n");
	printf("请输入群号或者成员账号\n");
	scanf("%s",  id);
	if(-1 == find_q_chat_id(id,q_chat_buf,len))
	{
	printf("查询群聊表记录失败\n");
	goto _out;
	}
	printf("查询群聊表记录成功\n");
	 */
	/*
	//通过账号或者对方账号查询单发文件表记录
	printf("查询单发文件表\n");
	printf("请输入账号\n");
	scanf("%s", id);
	if(-1 == find_d_send_id(id,&d_send))
	{
	printf("查询单发文件表记录失败\n");
	goto _out;
	}
	printf("查询单发文件表记录成功\n");


	printf("查询群发文件记录\n");
	printf("请输入群号或者qq账号\n");
	scanf("%s", id);
	if(-1 == find_q_send_id(id,&q_send))
	{
	printf("查询群发文件记录失败\n");
	goto _out;
	}
	printf("查询群发文件记录成功\n");
	 */

/*	// 通过账号删除用户表记录
	printf("删除用户表记录\n");
	printf("请输入想删除的账号\n");
	scanf("%s", id);
	d =  Judge_usr_id(id,usr_buf);
	if(d == -1)
	{
		printf("执行预编译语句失败\n");
		goto _out;
	}
	else if(d == 0)
	{
		printf("账号不存在,不能删除\n");
		goto _out;

	}
	if(-1 == delete_usr(id))
	{
		printf("执行预编译语句失败\n");
		goto _out;

	}
	else
	{
		printf("执行预编译语句成功\n");
	}
*/
	/*
	   for (i = 0; i < 128; i++)
	   {
	//	if ((strcmp(id, usr_buf[i].usr_id) == 0) || (strcmp(nick_name,usr_buf[i].usr_name) == 0))
	if(strcmp(id,usr_buf[i].usr_id) == 0)
	{

	break;
	}
	}
	if (i < 128)
	{
	if(-1 == delete_usr(id))
	{
	printf("删除用户表的记录失败\n");
	goto _out;
	}
	printf("执行预编译命令成功\n");
	}
	else
	{
	printf("不存在这个成员\n");
	}

	 */
	/*	// 通过账号或者好友账号删除好友表记录
		printf("删除好友表记录\n");
		printf("请输入要删除的账号\n");
		scanf("%s", id);
		for(i = 0; i < 128; i++)
		{
		if((strcmp(f_buf[i].from_id,id) == 0) || (strcmp(f_buf[i].to_id,id) == 0))
		{
		printf("好友表存在该账号\n");
		break;
		}


		}
		if(i < 128)
		{

		if(-1 == delete_friend(id))
		{
		printf("删除好友表记录\n");
		goto _out;

		}

		printf("执行预编译语句成功\n");

		}
		else 
		{
		printf("好友表里没有这个成员\n");
		}
	 */
	/*	// 通过账号或者好友账号删除好友聊天表记录
		printf("删除好友聊天表记录\n");
		printf("请输入要删除的账号\n");
		scanf("%s", id);
		if(-1 == delete_f_chat(id))
		{
		printf("删除好友表记录\n");
		goto _out;
		}
		printf("执行预编译删除语句成功\n");


*/
	//通过群号和群成员账号删除群成员
	printf("删除群成员\n");
	printf("请输入群号和要删除的成员账号\n");
	scanf("%s %s", Q_id,id);
	int r = delete_qq(Q_id,id,admin,q_buf,db);
	printf("r = %d\n",r);
    if(r == -2)
	{
	    printf("没有创建该群\n");
		goto _out;
	
	}
	else if(r == -1)
	{
		printf("该群没有该成员账号\n");
		goto _out;
	}
	else
	{
		printf("删除成员成功\n");
	}


/*
	//通过群号或者群成员账号删除群关联表
	printf("删除群聊表记录\n");
	printf("请输入要删除的账号\n");
	scanf("%s", id);
	if(-1 == delete_q_chat(id))
	{
	printf("删除群聊表记录\n");
	goto _out;
	}
	printf("执行预编译删除语句成功\n");
	 */
_out:
	sqlite3_close(db);

	return 0;

}






