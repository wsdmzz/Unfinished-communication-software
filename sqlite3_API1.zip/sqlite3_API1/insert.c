#include <stdio.h>

#include "insert.h"
#include <string.h>
#include "sqlite3.h"

//extern sqlite3 *db;


//注册用户信息表
int insert_usr(char *usr_id,char *usr_admin,char *nick_name,char *phone,sqlite3 *db)
{
	//  sqlite3 *db;

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成注册占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into usr values (?,?,?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定  数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,usr_id,strlen(usr_id),             SQLITE_TRANSIENT))
	{
		printf("绑定注册登陆账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,usr_admin,strlen(usr_admin),       SQLITE_TRANSIENT))
	{
		printf("绑定注册登陆密码失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,3,nick_name,strlen(nick_name),       SQLITE_TRANSIENT))
	{
		printf("绑定注册昵称失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	if(SQLITE_OK != sqlite3_bind_text(stmt,4,phone,strlen(phone),               SQLITE_TRANSIENT))
	{
		printf("绑定注册手机号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("注册记录失败\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;

}


// 添加好友信息表
int insert_friend(char *from_id,char *to_id,char *nickname,char *time,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成注册占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into friend values (?,?,?,?)");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//绑定  数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,from_id,strlen(from_id),           SQLITE_TRANSIENT))
	{
		printf("绑定用户账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,to_id,strlen(to_id),           SQLITE_TRANSIENT))
	{
		printf("绑定用户账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	if(SQLITE_OK != sqlite3_bind_text(stmt,3,nickname,strlen(nickname),         SQLITE_TRANSIENT))
	{
		printf("绑定备注昵称失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	if(SQLITE_OK != sqlite3_bind_text(stmt,4,time,strlen(time),                 SQLITE_TRANSIENT))
	{
		printf("绑定添加好友时间失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("注册记录失败\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;
}


// 添加好友聊天表信息
int insert_h_chat(char *f_id,char *t_id,char *buf,char *time,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成注册占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into  H_chat values (?,?,?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定好友表数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,f_id,strlen(f_id),                 SQLITE_TRANSIENT))
	{
		printf("绑定账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,t_id,strlen(t_id),                 SQLITE_TRANSIENT))
	{
		printf("绑定对方账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,3,buf,strlen(buf),SQLITE_TRANSIENT))
	{
		printf("绑定聊天记录:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	if(SQLITE_OK != sqlite3_bind_text(stmt,4,time,strlen(time),                 SQLITE_TRANSIENT))
	{
		printf("绑定聊天时间:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("添加好友聊天表记录\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;
}

//创建群，添加群号表记录
int insert_q(char *Q_id,char *Q_admin,sqlite3 *db)
{
	sqlite3_stmt *stmt;    //输出预编译语句对象指针
	char sql[128];
	//生成注册占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into q_Q_id values (?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定群号跟群主账号数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,Q_id,strlen(Q_id),             SQLITE_TRANSIENT))
	{
		printf("绑定群账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,Q_admin,strlen(Q_admin),SQLITE_TRANSIENT))
	{
		printf("绑定群员账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("添加群号表记录失败\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;

}


// 添加群关系表记录
int insert_QQ(char *q_id, char *id,char *nick_name,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成注册占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into QQ values (?,?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定群号跟群成员账号数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,q_id,strlen(q_id),                 SQLITE_TRANSIENT))
	{
		printf("绑定群账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定群员账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,3,nick_name,strlen(nick_name),       SQLITE_TRANSIENT))
	{
		printf("绑定群员名称失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("添加群关系表记录失败\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;

}

//添加群聊表记录
int insert_q_chat(char *Q_id,char *id,char *nick_name,char *q_buf,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成插入群聊表记录占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into  Q_chat values (?,?,?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定聊天表记录数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,Q_id,strlen(Q_id),         SQLITE_TRANSIENT))
	{
		printf("绑定群号账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),                 SQLITE_TRANSIENT))
	{
		printf("绑定群成员账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,3,nick_name,strlen(nick_name),SQLITE_TRANSIENT))
	{
		printf("绑定成员所在名称:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,4,q_buf,strlen(q_buf),SQLITE_TRANSIENT))
	{
		printf("绑定群记录失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("添加群聊表记录失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);
	return 0;
}

// 添加单发文件表记录
int insert_d_fd(char *f_id,char *t_id,char *filename,char *time,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成插入单发文件记录占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into  D_send values (?,?,?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定单发文件记录数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,f_id,strlen(f_id),         SQLITE_TRANSIENT))
	{
		printf("绑定发送方账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,t_id,strlen(t_id),                 SQLITE_TRANSIENT))
	{
		printf("绑定接受方账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,3,filename,strlen(filename),SQLITE_TRANSIENT))
	{
		printf("绑定文件名失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,4,time,strlen(time),SQLITE_TRANSIENT))
	{
		printf("绑定发送时间失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("添加单发文件记录失败\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;
}

// 添加群发文件表记录
int insert_q_fd(char *f_id,char *Q_id,char *filename,char *time,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	//生成插入单发文件记录占位预编译占位字符串
	snprintf(sql,sizeof sql, "insert into  Q_send values (?,?,?,?)");

	//创建并初始化预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}
	//绑定群发文件记录数据到预编译语句
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,f_id,strlen(f_id),         SQLITE_TRANSIENT))
	{
		printf("绑定发文件者账号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,Q_id,strlen(Q_id),         SQLITE_TRANSIENT))
	{
		printf("绑定群号失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}


	if(SQLITE_OK != sqlite3_bind_text(stmt,3,filename,strlen(filename),     SQLITE_TRANSIENT))
	{
		printf("绑定文件名失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,4,time,strlen(time),SQLITE_TRANSIENT))
	{
		printf("绑定文件名失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}

	//执行预编译语句
	if(SQLITE_DONE !=  sqlite3_step(stmt))
	{
		printf("添加单发文件记录失败\n");
		return -1;
	}
	//重复绑定时，复位预编译语句,清除绑定
	sqlite3_reset(stmt);
	//以下函数用于清除绑定
	sqlite3_clear_bindings(stmt);

	return 0;
}
