#include <stdio.h>
#include "find.h"
#include "judge.h"
#include <string.h>
#include <stdbool.h>
#include "find.h"
#include "sqlite3.h"

/**
 * 功能：判断账号在不在用户表里
 * 参数：id  判断的账号指针
 *       s   贮存用户表信息的数组
 * 返回值：成功返回0,失败返回 -1
 **/
int Judge_usr_id(char *id,usr_t *s,sqlite3 *db)
{
	int i = 0;
	int ret = 0;

	ret = select_usr_id(id,s,db);
	if(ret == -1)
	{
		printf("执行预编译查找用户记录语句失败\n");
		return -1;
	}
	else if(ret == 0)   //用户表没有记录
	{
	   return 0;
	}
    else              //用户表有记录
	{
		return 1;
	}

    return 0;
}
