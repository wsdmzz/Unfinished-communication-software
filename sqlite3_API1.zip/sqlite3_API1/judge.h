#ifndef _JUDGE_H
#define _JUDGE_H

#include "sqlite3.h"
/**
 * 功能：判断账号在不在用户表里
 * 参数：id  判断的账号指针
 *       s   贮存用户表信息的数组
 *       
 * 返回值：不存在返回0,账号存在返回1,查询失败返回-1
 **/
int Judge_usr_id(char *id,usr_t *s,sqlite3 *db);

/**
 *
 *
 ********/
#endif
