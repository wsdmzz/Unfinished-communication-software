#include <stdio.h>
#include "delete.h"
#include <string.h>
#include "sqlite3.h"


// 通过账号或者用户昵称删除用户记录
int delete_usr(char *id,sqlite3 *db)
{		
    sqlite3_stmt *stmt;    //输出预编译语句对象
    char sql[128];

    //生成注册占位预编译占位字符串
    sqlite3_snprintf(sizeof sql,sql, "delete from usr where usr_id = ?");

    //创建预编译语句对象
    if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
    {
        printf("预编译失败:%s\n",sqlite3_errmsg(db));
        return -1;

    }
    // 绑定账号参数
    if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定账号失败\n");
        return -1;
    }
    

	//执行预编译语句
	if(SQLITE_DONE != sqlite3_step(stmt))
	{
		printf("删除用户记录失败\n");
		return -1;
	}


// 复位预编译语句对象
    sqlite3_reset(stmt);

    //销毁预编译语句对象
    sqlite3_finalize(stmt);

    return 0;
}

// 通过对方账号或者好友账号删除好友表记录
int delete_friend(char *id,sqlite3 *db)
{
    sqlite3_stmt *stmt;    //输出预编译语句对象
    char sql[128];
    

    //生成注册占位预编译占位字符串
    sqlite3_snprintf(sizeof sql,sql, "delete from friend where from_id = ?  or  to_id = ?");

    //创建预编译语句对象
    if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
    {
        printf("预编译失败:%s\n",sqlite3_errmsg(db));
        return -1;

    }
    // 绑定账号参数
    if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定账号失败\n");
        return -1;
    }
    if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定好友账号失败\n");
        return -1;
    }

	//执行预编译语句
	if(SQLITE_DONE != sqlite3_step(stmt))
	{
		printf("执行预编译语句失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}


// 复位预编译语句对象
    sqlite3_reset(stmt);

    //销毁预编译语句对象
    sqlite3_finalize(stmt);

    return 0;
}

// 通过账号或者好友账号删除好友聊天表记录
int delete_f_chat(char *id,sqlite3 *db)
{
    sqlite3_stmt *stmt;    //输出预编译语句对象
    char sql[128];
    

    //生成注册占位预编译占位字符串
    sqlite3_snprintf(sizeof sql,sql, "delete from H_chat where from_id = ?  or  to_id = ?");

    //创建预编译语句对象
    if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
    {
        printf("预编译失败:%s\n",sqlite3_errmsg(db));
        return -1;

    }
    // 绑定账号参数
    if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定账号失败\n");
        return -1;
    }
    if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定好友账号失败\n");
        return -1;
    }

	//执行预编译语句
	if(SQLITE_DONE != sqlite3_step(stmt))
	{
		printf("执行预编译语句失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}


// 复位预编译语句对象
    sqlite3_reset(stmt);

    //销毁预编译语句对象
    sqlite3_finalize(stmt);

    return 0;
}



// 通过群号和群成员账号删除群关联表的成员
int delete_qq(char *Q_id,char *id,char *admin,QQ_t *s,sqlite3 *db)
{
    sqlite3_stmt *stmt;    //输出预编译语句对象
    char sql[128];
    
	//判断有没有这个群
    
	//在判断该群有没有这个成员
     int ret = judge_qun(Q_id,id,admin,s,db);
	 if(ret == -2)        //判断没有这个群
	 {
		 return -2;
	 }
	 else if(ret == -1)   //判断没有这个成员账号
	 {
		 return -1;     
	 }
    //生成注册占位预编译占位字符串
    sqlite3_snprintf(sizeof sql,sql, "delete from QQ where	Q_id = ?  and   id = ?");

    //创建预编译语句对象
    if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
    {
        printf("预编译失败:%s\n",sqlite3_errmsg(db));
        return -1;

    }
    // 绑定账号参数
    if(SQLITE_OK != sqlite3_bind_text(stmt,1,Q_id,strlen(Q_id),SQLITE_TRANSIENT))
    {
        printf("绑定群号失败\n");
        return -1;
    }
    if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定群成员账号失败\n");
        return -1;
    }

	//执行预编译语句
	if(SQLITE_DONE != sqlite3_step(stmt))
	{
		printf("执行预编译语句失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}


// 复位预编译语句对象
    sqlite3_reset(stmt);

    //销毁预编译语句对象
    sqlite3_finalize(stmt);

    return 0;
}



// 通过群号或者群成员账号删除群聊录
int delete_q_chat(char *id,sqlite3 *db)
{
    sqlite3_stmt *stmt;    //输出预编译语句对象
    char sql[128];
    

    //生成注册占位预编译占位字符串
    sqlite3_snprintf(sizeof sql,sql, "delete from Q_chat where	Q_id = ?  or  Q_number = ?");

    //创建预编译语句对象
    if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
    {
        printf("预编译失败:%s\n",sqlite3_errmsg(db));
        return -1;

    }
    // 绑定账号参数
    if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定群号失败\n");
        return -1;
    }
    if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
    {
        printf("绑定群成员账号失败\n");
        return -1;
    }

	//执行预编译语句
	if(SQLITE_DONE != sqlite3_step(stmt))
	{
		printf("执行预编译语句失败:%s\n",sqlite3_errmsg(db));
		return -1;
	}


// 复位预编译语句对象
    sqlite3_reset(stmt);

    //销毁预编译语句对象
    sqlite3_finalize(stmt);

    return 0;
}



