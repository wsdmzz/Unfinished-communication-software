#include <stdio.h>
#include "find.h"
#include <string.h>

#include "sqlite3.h"

//extern sqlite3 *db;


// 通过用户登陆账号查询用户表个人信息，并保存在数组s里面
int select_usr_id(char *id, usr_t *arr,sqlite3 *db)
{


	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	int i;

	//生成注册占位预编译占位字符串,一个占位符就绑定一次
	sqlite3_snprintf(sizeof sql,sql, "select * from usr where usr_id = ?");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}


     i = 0;
	//有记录则处理
	while(SQLITE_ROW == sqlite3_step(stmt))
	{
		

		// 获取一行数据(一条用户个人信息)
		strncpy(arr[i].usr_id,sqlite3_column_text(stmt,0),sizeof arr[i].usr_id);
		strncpy(arr[i].usr_admin,sqlite3_column_text(stmt,1),sizeof arr[i].usr_admin);
		strncpy(arr[i].usr_name,sqlite3_column_text(stmt,2),sizeof arr[i].usr_name);
		strncpy(arr[i].usr_phone_number,sqlite3_column_text(stmt,3),sizeof arr[i].usr_phone_number);

		// 打印用户信息
//		printf("%s\t%s\t%s\t%s\n", arr[i].usr_id,arr[i].usr_admin,
//					arr[i].usr_name,arr[i].usr_phone_number);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	//如果i 为-1 证明查询失败,i 为0，证明没有用户记录,如果不是0，证明该账号已存在,不能重复添加或者注册
	return i;
}


// 无条件查询 用户表 全部信息,保存在结构体定义的s 的数组
int select_usr(usr_t  *s,sqlite3 *db)
{

    
	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from  usr");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}

	int i = 0;
	
	//有记录则处理
	for(;SQLITE_ROW == sqlite3_step(stmt);i++)
	{

		// 获取一行数据(一个学生信息)
		strncpy(s[i].usr_id,sqlite3_column_text(stmt,0),sizeof s[i].usr_id);
		strncpy(s[i].usr_admin,sqlite3_column_text(stmt,1),sizeof s[i].usr_admin);
		strncpy(s[i].usr_name,sqlite3_column_text(stmt,2),sizeof s[i].usr_name);

		strncpy(s[i].usr_phone_number,sqlite3_column_text(stmt,3),sizeof s[i].usr_phone_number);

		// 打印用户信息
		printf("%s\t%s\t%s\t%s\n", s[i].usr_id,s[i].usr_admin,
					s[i].usr_name,s[i].usr_phone_number);

		

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return 0;



}


//根据双方账号查询好友表个人信息,判断是不是好友关系,并保存在数组s里面
int select_friend_id(char *f_id, char *t_id,friend_t *s,sqlite3 *db)
{


	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from friend  where from_id  = ? and to_id = ?");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,f_id,strlen(f_id),SQLITE_TRANSIENT))
	{
		printf("绑定好友账号失败\n");
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,t_id,strlen(t_id),SQLITE_TRANSIENT))
	{
		printf("绑定好友账号失败\n");
		return -1;
	}

	int i = 0;
	//有记录则处理,执行预编译语句
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一个好友)
		strncpy(s[i].from_id,sqlite3_column_text(stmt,0),sizeof s[i].from_id);
		strncpy(s[i].to_id,sqlite3_column_text(stmt,1),sizeof s[i].to_id);

		strncpy(s[i].nick_name,sqlite3_column_text(stmt,2),sizeof s[i].nick_name);

		strncpy(s[i].time,sqlite3_column_text(stmt,3),sizeof s[i].time);

		// 打印好友表个人信息
		printf("%s\t%s\t%s\t%s\n", s[i].from_id,s[i].to_id,
					s[i].nick_name,s[i].time);
		
		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;
}



//无条件查询好友表所有信息并保存在数组s里面
int select_friend(friend_t *s,sqlite3 *db)
{


	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from friend ");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
		


	int i = 0;
	//有记录则处理,执行预编译语句
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一个好友)
		strncpy(s[i].from_id,sqlite3_column_text(stmt,0),sizeof s[i].from_id);
		strncpy(s[i].to_id,sqlite3_column_text(stmt,1),sizeof s[i].to_id);

		strncpy(s[i].nick_name,sqlite3_column_text(stmt,2),sizeof s[i].nick_name);

		strncpy(s[i].time,sqlite3_column_text(stmt,3),sizeof s[i].time);

		// 打印好友表个人信息
		printf("%s\t%s\t%s\t%s\n", s[i].from_id,s[i].to_id,
					s[i].nick_name,s[i].time);
		
		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;
}



// 通过甲方账号和对方账号来查询有没有单聊表记录,并保存在数组f里
int find_d_chat_id(char *f_id,char *t_id,chat_t *f,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from H_chat where from_id = ? and to_id = ? ");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定聊天账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,f_id,strlen(f_id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,t_id,strlen(t_id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}
	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条聊天记录)
		strncpy(f[i].f_id,sqlite3_column_text(stmt,0),sizeof f[i].f_id);
		strncpy(f[i].t_id,sqlite3_column_text(stmt,1),sizeof f[i].t_id);
		strncpy(f[i].c_buf,sqlite3_column_text(stmt,2),sizeof f[i].c_buf);
		strncpy(f[i].time,sqlite3_column_text(stmt,3),sizeof f[i].time);

		// 打印单聊表记录
		printf("%s\t%s\t%s\t%s\n", f[i].f_id,f[i].t_id,
					f[i].c_buf,f[i].time);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);
	//i 表示查询到的单聊表记录
	return i;

}


// 无条件查询 单聊表 所有记录,并保存在数组f里
int find_d_chat(chat_t *f,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from H_chat");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	

	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条聊天记录)
		strncpy(f[i].f_id,sqlite3_column_text(stmt,0),sizeof f[i].f_id);
		strncpy(f[i].t_id,sqlite3_column_text(stmt,1),sizeof f[i].t_id);
		strncpy(f[i].c_buf,sqlite3_column_text(stmt,2),sizeof f[i].c_buf);
		strncpy(f[i].time,sqlite3_column_text(stmt,3),sizeof f[i].time);

		// 打印单聊表记录
		printf("%s\t%s\t%s\t%s\n", f[i].f_id,f[i].t_id,
					f[i].c_buf,f[i].time);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);
	return i;

}

//通过群号查询群号表是否已经创建该群,把群主号保存在指针Q_admin,返回ret
char* find_q_Q_id(char *Q_id,char *Q_admin,sqlite3 *db)
{

	char *ret = NULL;
	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from q_Q_id where Q_id = ? ");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return NULL;

	}
	// 绑定群号账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,Q_id,strlen(Q_id),SQLITE_TRANSIENT))
	{
		printf("绑定群账号失败\n");
		return NULL;
	}


	//有记录则处理(执行预编译语句)
	if(SQLITE_ROW == sqlite3_step(stmt))
	{
		
		// 将群号表中的第1条记录中的第2个字段群主id保存在Q_admin指针里
	    strncpy(Q_admin,sqlite3_column_text(stmt,1),sizeof Q_admin);
		 ret = Q_admin;	  //将群注id赋值给ret

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	//返回ret,如果为NULL,证明没有创建该群,不是NULL，证明已经创有群，并保存群主ID在Q_admin指针里
	return ret;
}
//通过群号和账号来查询 是否有无群关系表 记录,并证明该账号是否是在群
int find_qq_id(char *f_id,char *t_id,QQ_t *f,sqlite3 *db)
{


	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from QQ where Q_id = ?"
				" and id  = ? ");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定群号或者成员账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,f_id,strlen(t_id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,t_id,strlen(t_id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}
	
	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条群关联表记录)
		strncpy(f[i].Q_id,sqlite3_column_text(stmt,0),sizeof f[i].Q_id);
		strncpy(f[i].id,sqlite3_column_text(stmt,1),sizeof f[i].id);
		strncpy(f[i].nick_name,sqlite3_column_text(stmt,2),sizeof f[i].nick_name);


		// 打印关联表记录
		printf("%s\t%s\t%s\n", f[i].Q_id,f[i].id,
					f[i].nick_name);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;

}


//无条件来查询 群关系表 所有记录
int find_qq(QQ_t *f,sqlite3 *db)
{


	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from QQ");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}

	
	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条群关联表记录)
		strncpy(f[i].Q_id,sqlite3_column_text(stmt,0),sizeof f[i].Q_id);
		strncpy(f[i].id,sqlite3_column_text(stmt,1),sizeof f[i].id);
		strncpy(f[i].nick_name,sqlite3_column_text(stmt,2),sizeof f[i].nick_name);


		// 打印单聊表记录
		printf("%s\t%s\t%s\n", f[i].Q_id,f[i].id,
					f[i].nick_name);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;

}
// 通过群号账号或者成员账号查询群聊表记录,保存在数组f
int find_q_chat_id(char *id, Q_chat_t  *f,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from Q_chat where Q_id = ?"
				  "or Q_number  = ? ");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定群号或者成员账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}

	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条群聊表记录)
		strncpy(f[i].Q_id,sqlite3_column_text(stmt,0),sizeof f[i].Q_id);
		strncpy(f[i].Q_number,sqlite3_column_text(stmt,1),sizeof f[i].Q_number);
		strncpy(f[i].nick_name,sqlite3_column_text(stmt,2),sizeof f[i].nick_name);
		strncpy(f[i].Q_buf,sqlite3_column_text(stmt,3),sizeof f[i].Q_buf);


		// 打印群聊表记录信息
		printf("%s\t%s\t%s\t%s\n", f[i].Q_id,f[i].Q_number,
					f[i].nick_name,f[i].Q_buf);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;

}

// 无条件查询群聊表 所有记录,保存在数组f
int find_q_chat(Q_chat_t  *f,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from Q_chat");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	

	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条群聊表记录)
		strncpy(f[i].Q_id,sqlite3_column_text(stmt,0),sizeof f[i].Q_id);
		strncpy(f[i].Q_number,sqlite3_column_text(stmt,1),sizeof f[i].Q_number);
		strncpy(f[i].nick_name,sqlite3_column_text(stmt,2),sizeof f[i].nick_name);
		strncpy(f[i].Q_buf,sqlite3_column_text(stmt,3),sizeof f[i].Q_buf);


		// 打印群聊表记录信息
		printf("%s\t%s\t%s\t%s\n", f[i].Q_id,f[i].Q_number,
					f[i].nick_name,f[i].Q_buf);

		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;

}

// 通过账号he对方账号 查询单发文件表  记录
int find_d_send(char *id, D_send_t  *f,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from D_send where from_id    = ? and  to_id  = ? ");
	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定发送账号或者对方账号查询单发文件
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定对方账号失败\n");
		return -1;
	}
	int i = 0;
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条单发文件表记录)
		strncpy(f->f_id,sqlite3_column_text(stmt,0),sizeof f->f_id);
		strncpy(f->t_id,sqlite3_column_text(stmt,1),sizeof f->t_id);
		strncpy(f->fd_name,sqlite3_column_text(stmt,2),sizeof f->fd_name);
        strncpy(f->s_time,sqlite3_column_text(stmt,3),sizeof f->s_time);

		// 打印群聊表记录信息
		printf("%s\t%s\t%s\t%s\n", f->f_id,f->t_id,
					f->fd_name,f->s_time);
		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return i;

}



// 通过群账号或者账号查询 群发文件表  记录
int find_q_send(char *id, Q_send_t  *f,sqlite3 *db)
{

	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];

	//生成注册占位预编译占位字符串
	sqlite3_snprintf(sizeof sql,sql, "select * from Q_send where from_id    = ? or Q_id  = ? ");
	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定发送账号或者群号查询 群发文件表记录
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}

	if(SQLITE_OK != sqlite3_bind_text(stmt,2,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定对方账号失败\n");
		return -1;
	}
	//有记录则处理(执行预编译语句)
	while(SQLITE_ROW == sqlite3_step(stmt))
	{

		// 获取一行数据(一条群发文件表记录)
		strncpy(f->f_id,sqlite3_column_text(stmt,0),sizeof f->f_id);
		strncpy(f->Q_id,sqlite3_column_text(stmt,1),sizeof f->Q_id);
		strncpy(f->fd_name,sqlite3_column_text(stmt,2),sizeof f->fd_name);
        strncpy(f->s_time,sqlite3_column_text(stmt,3),sizeof f->s_time);

		// 打印群聊表记录信息
		printf("%s\t%s\t%s\t%s\n", f->f_id,f->Q_id,
					f->fd_name,f->s_time);

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	return 0;

}


//通过用户账号和用户密码判断 是否用户登陆成功
int yan_usr(char *id, char *admin,usr_t *arr,sqlite3 *db)
{


	sqlite3_stmt *stmt;    //输出预编译语句对象
	char sql[128];
	int i;

	//验证账号是否错误
    int ret = select_usr_id(id,arr,db);
	if(ret <= 0)
	{
		return -2;   //账号不存在

	}
		
	//生成注册占位预编译占位字符串,一个占位符就绑定一次
	sqlite3_snprintf(sizeof sql,sql, "select * from usr where usr_id = ?     and usr_admin = ?");

	//创建预编译语句对象
	if(SQLITE_OK != sqlite3_prepare(db,sql,-1,&stmt,NULL))
	{
		printf("预编译失败:%s\n",sqlite3_errmsg(db));
		return -1;

	}
	// 绑定账号参数
	if(SQLITE_OK != sqlite3_bind_text(stmt,1,id,strlen(id),SQLITE_TRANSIENT))
	{
		printf("绑定账号失败\n");
		return -1;
	}
	if(SQLITE_OK != sqlite3_bind_text(stmt,2,admin,strlen(admin),SQLITE_TRANSIENT))
	{
		printf("绑定用户密码失败\n");
		return -1;
	}

     i = 0;
	//有记录则处理
	while(SQLITE_ROW == sqlite3_step(stmt))
	{
		
		i++;

	}
	// 复位预编译语句对象
	sqlite3_reset(stmt);

	//销毁预编译语句对象
	sqlite3_finalize(stmt);

	//如果i 为-2 证明账号不存在,-1 证明查询失败,i为0，密码错误,如果不是0，证明该用户账号和密码正确,验证成功
	return i;


}

int judge_qun(char *Q_id,char *id,char *admin,QQ_t *s,sqlite3 *db)
{
	//判断有没有这个群
	char *r = find_q_Q_id(Q_id,admin,db);  //没有这个群
	if(r == NULL)
	{
		return -2;       
	}
	printf("r = %s\n",r);
	//判断群里有没有这个成员
	if(find_qq_id(Q_id,id,s,db) <= 0)
	{
		return -1;
	}
	else
	  return 0;
	
}



