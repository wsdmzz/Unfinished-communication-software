/*================================================================
 * 
 *   Copyright (C) 2019 Sangfor Ltd. All rights reserved.
 *   
 *   文件名称：tcpientc
 *   创 建 者：Sunchen
 *   创建日期：2019年01月05日
 *   描    述：
 *
 ================================================================*/

#include <stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "client.h"
//unsigned char message[1024];
int landing();
int registerl();
int Find_friends();
int Add_friends();
int Create_group();
int Add_or_retreat();
int ClientGeneral_Answer();
int Client_Chat();
int AddFriend_Response();
int parseDataCmd(int cltSock, char *msg, int length);
//界面
int Interface(unsigned char *msg,int *len)
{

		int m;
		while(1)
		{
				printf("\n\n");
				printf("\t┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n");
				printf("\t┃         chat_QQ1.0      ┃\n");
				printf("\t┃                   by YQ ┃\n");
				printf("\t┃  1、注册                ┃\n");
				printf("\t┃  2、登录                ┃\n");
				printf("\t┃  3、查找好友            ┃\n");
				printf("\t┃  4、添加好友            ┃\n");
				printf("\t┃  5、创建群              ┃\n");
				printf("\t┃  6、加群退群            ┃\n");
				printf("\t┃  7、客户端通用应答      ┃\n");
				printf("\t┃  8、客户端聊天          ┃\n");
				printf("\t┃  9、客户端添加好友回应  ┃\n");
				printf("\t┃                         ┃\n");
				printf("\t┗━━━━━━━━━━━━━━━━━━━━━━━━━┛\n\n");
				printf("Please enter an operation item\n");
				scanf("%d",&m);
			//	setbuf(stdin, NULL);
			  char ch;while((ch=getchar())!='\n'&&ch!=EOF);
			    
				switch(m)
				{
						case 1:
								//注册
								registerl(msg, &len);
								break;
						case 2:
								//登录
								landing(msg, &len);
								break;
						case 3:
								//查找好友
								Find_friends(msg, &len);
								break;
						case 4:
								//添加好友
								Add_friends(msg, &len);
								break;
						case 5:
								//创建群
								Create_group(msg, &len);
								break;
						case 6:
								//加群退群
								Add_or_retreat(msg, &len);
								break;
						case 7:
								//客户端通用应答
								ClientGeneral_Answer(msg, &len);
								break;
						case 8:
								//客户端聊天
								Client_Chat(msg, &len);
								break;
						case 9:
								//客户端加好友回应
								AddFriend_Response(msg, &len);
								break;
						default:
								printf("重新输入\n");
								break;
				}
		}
		return 0;
}
int main(int argc,unsigned char *argv[])
{

		unsigned char msg[1024] = "";
		int len = 0;
		int sockfd;
		in_port_t port;//端口
		struct sockaddr_in svr_addr;//服务器
		unsigned char buf[32];
		unsigned char *ip;
		FILE *stream;
		in_addr_t inaddr;

		if(argc != 3)
		{
				printf("用法%s<服务器ip><端口号>\n",argv[0]);
				return -1;
		}
		ip = argv[1];
		port = atoi(argv[2]);
		sockfd = socket(AF_INET,SOCK_STREAM,0);
		if(-1 == sockfd)
		{
				perror("创建套接字失败\n");
				return -1;
		}
		inaddr = inet_addr(ip);
		if(INADDR_NONE == inaddr)
		{
				printf("%s是非法地址\n",ip);
				goto _out;
		}

		svr_addr.sin_family = AF_INET;
		svr_addr.sin_port = htons(port);
		svr_addr.sin_addr.s_addr = inaddr;
		//svr_addr.sin_addr.s_addr = htonl(INADDR_ANY);

		if(-1 == connect(sockfd,(struct sockaddr *)&svr_addr,sizeof(svr_addr)))
		{
				perror("服务器连接失败\n");
				goto _out;
		}
		printf("连接成功\n");



		Interface(msg, &len);

		while(1)
		{
				//		for(int l=0;l<len;l++)
				//		{
				//				printf("%02x\n", msg[l]);
				//		}
				if(-1 == write(sockfd,msg,len))
				{

						perror("发送信息失败\n");
						goto _out;
				}
				printf("发送信息成功\n");
				//收
				//	while(1)
				//	{
				int len;
				if(-1 == (len=read(sockfd,buf,sizeof(buf))))
				{
						perror("接收信息失败\n");
						goto _out;
				}
				int parseDataCmd(int cltSock, &buf, len);

				for(int l=0; l<len;l++)
				{
						printf("收到服务器信息:%02x\n",buf[l]);
				}
				break;
		}
		//	}
_out:
		close(sockfd);
		return 0;
}
