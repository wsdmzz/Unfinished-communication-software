/*================================================================
*   Copyright (C) 2019 Sangfor Ltd. All rights reserved.
*   
*   文件名称：client.h
*   创 建 者：Sunchen
*   创建日期：2019年01月25日
*   描    述：
*
================================================================*/

#ifndef CLIENT_H
#define CLIENT_H
#include <stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
//#include "client.h"
#define DATAHEAD 0x7E
#define DATATAIL 0x7E

bool checkDatas(char *msg, int length);
int parseDataCmd(int cltSock, char * msg,int length);
unsigned char xorDatasOneByOne(char *msg, int length);
unsigned long  BCDtoDec(const unsigned char *bcd, int length);

extern unsigned char message[1024];
#endif
