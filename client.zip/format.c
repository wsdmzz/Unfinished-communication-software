/*================================================================
 * 
 *   Copyright (C) 2019 Sangfor Ltd. All rights reserved.
 *   
 *   文件名称：1.c
 *   创 建 者：Sunchen
 *   创建日期：2019年02月16日
 *   描    述：
 *
 ================================================================*/


#include <stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <math.h>
#include "client.h"
static unsigned char account[7];		
long Serial_number=0;
unsigned char message[1024]="";
int HexValue(unsigned char a);
int HexStrValue(unsigned char str[]);
int registerl();
int landing();
//dec转16进制
int DecToBCD(long Dec, unsigned char *Bcd, int length) 
{ 
		long tmp; 
		int i = 0;
		for(i = length - 1; i >= 0; i--) 
		{ 
				tmp = Dec % 100; 
				Bcd[i] = ((tmp / 10) << 4) + ((tmp % 10) & 0x0F); 
				Dec /= 100; 
		} 
		return 0; 
}
//10转16
int DecToHex(long dec, unsigned char *hex, int length)
{
		int i;
		for (i = length - 1; i >= 0; i--)
		{
				hex[i] = (dec % 256) & 0xFF;
				dec /= 256;
		}
		return 0;
}
//异或校验

int GetCRCSum(unsigned char *buffer, int len)
{
		int dwI = 0;
		unsigned char checksum = buffer[1];
		for(dwI=2; dwI<len; dwI++)
		{
				checksum ^=buffer[dwI];
		}
		return checksum;
}
//两个16进制合并
unsigned char *Change(unsigned char *t,unsigned char *s)
{
		unsigned char i,chs;
		for(i = 0; s[i]; ++i) {
				chs = s[i] & 0X0F;
				t[3 * i + 2] = ' ';
				if(chs > 9) t[3 * i + 1] = chs - 10 + 'A';
				else t[3 * i + 1] = chs + '0';
				chs = (s[i] & 0XF0) >> 4;
				if(chs > 9) t[3 * i] = chs - 10 + 'A';
				else t[3 * i] = chs + '0';
		}
		t[3 * i] = '\0';
		return t;
}
//ascii转16进制
unsigned char *chstohex ( unsigned char* chs )
{
		unsigned char hex[16] = { '0', '1', '2', '3', '4', '5', '6', \
				'7', '8','9', 'A', 'B', 'C', 'D', 'E', 'F' 
		};  
		int len = strlen ( chs );
		unsigned char* ascii = NULL ;
		ascii = (unsigned char*)calloc ( len * 3 + 1, sizeof(unsigned char) );            // calloc ascii
		int i = 0;
		while( i < len )
		{   
				ascii[i*2] = hex[(int)( (unsigned char)chs[i] / 16 )] ;
				ascii[i*2 + 1] = hex[(int)( (unsigned char)chs[i] % 16 )] ;
				++i;
		}   
		return ascii;                    // ascii 返回之前未释放
}
//字符串转int
long myatoi(unsigned char s[])  
{  
		int i;  
		long n = 0;  
		for (i = 0; s[i] >= '0' && s[i] <= '9'; ++i)  
		{  
				n = 10 * n + (s[i] - '0');  
		}	
		return n;  
}  
//合并子函数
int HexValue(unsigned char a)
{
		a -= 48;
		if(a > 9 ) a -= 7;
		return a;
}
//合并子函数
int HexStrValue(unsigned char str[])
{
		int v=0;
		for(int ii=0 ;ii<(int)strlen(str); ii++)
		{ 
				v <<=4;
				v += HexValue(str[ii]);
		}
		return v;
}
//注册
int registerl(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=100;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//昵称
		unsigned char name[20]="";
		printf("Please enter a nickname(Letter)\n");
		fgets(name,20,stdin);
		setbuf(stdin, NULL);
		count+=strlen(name);
		Change(tmpbuf,name);

		//密码
		unsigned char password[20]="";
		printf("Please input a password \n");
		fgets(password,20,stdin);
		Change(tmpbuf1,password);
		count+=strlen(password);
		setbuf(stdin, NULL);

		//手机号
		printf("Please enter your cell phone number\n");
		fgets(number,12,stdin);
		count+=strlen(number);
		setbuf(stdin, NULL);
		long uid=myatoi(number);
		DecToBCD(uid, tmpbuf2, 6);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

		//账户ID
		index +=6;	
	
		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//昵称
		for(i=0;i<strlen(tmpbuf);i+=3)
		{

				tmp[0] = tmpbuf[i];
				tmp[1] = tmpbuf[i+1];
				if(tmp[0]!='0'&&tmp[1]!='a')
				{
						//	printf("%02x %02x\n", tmp[0], tmp[1]);
						changeData = HexStrValue(tmp);
						message[index++]=changeData;
				}
		}
		message[index++]=0x00;


		//密码
		for(i=0;i<strlen(tmpbuf1);i+=3)
		{
				tmp[0] = tmpbuf1[i];
				tmp[1] = tmpbuf1[i+1];
				if(tmp[0]!='0'&&tmp[1]!='a')
				{
						//		printf("%02x %02x\n", tmp[0], tmp[1]);
						changeData = HexStrValue(tmp);
						message[index++]=changeData;
				}
		}
		message[index++]=0x00;
		


		//手机号
		for(i = 0;i < 6;i++)
		{
				//	printf("%02x\n", tmpbuf2[i]);
				message[index++]=tmpbuf2[i];

		}
		message[index++]=0x00;


		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//登录
int landing(unsigned char *msg, int *length)
{

		
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="",tmpbuf4[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=102;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//帐号
		printf("Please enter your account\n");
		fgets(account,7,stdin);
		setbuf(stdin, NULL);
		count += strlen(account);
		
		
		

		//密码
		unsigned char password[20]="";
		printf("Please input a password \n");
		fgets(password,20,stdin);
		setbuf(stdin, NULL);
		Change(tmpbuf1,password);
		count+=strlen(password);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

		//帐号
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}

		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//帐号
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}


		//密码
		for(i=0;i<strlen(tmpbuf1);i+=3)
		{
				tmp[0] = tmpbuf1[i];
				tmp[1] = tmpbuf1[i+1];
				if(tmp[0]!='0'&&tmp[1]!='a')
				{
						//      printf("%02x %02x\n", tmp[0], tmp[1]);
						changeData = HexStrValue(tmp);
						message[index++]=changeData;
				}
		}
		message[index++]=0x00;

		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}

		*length = index;
		memcpy(msg, message, index);
		return 0;

}
//查找好友
int Find_friends(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=104;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//查找帐号
		printf("Please enter your account\n");
		unsigned char acc[7];		
		fgets(acc,7,stdin);
		setbuf(stdin, NULL);
		count += strlen(acc);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}

		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//帐号
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=acc[k];

		}

		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//添加好友
int Add_friends(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=105;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//帐号
		printf("Please enter your account\n");
		unsigned char acc[7];		
		fgets(acc,7,stdin);
		setbuf(stdin, NULL);
		count += strlen(acc);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}

		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//帐号
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=acc[k];

		}

		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//创建群
int Create_group(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=303;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//手机号
		printf("Please enter your cell phone number\n");
		fgets(number,12,stdin);
		count+=strlen(number);
		setbuf(stdin, NULL);
		long uid=myatoi(number);
		DecToBCD(uid, tmpbuf2, 6);

		//群昵称
		unsigned char name[20]="";
		printf("Please enter a nickname(Letter)\n");
		fgets(name,20,stdin);
		setbuf(stdin, NULL);
		count+=strlen(name);
		Change(tmpbuf,name);


		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}
			
	
		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//群昵称
		for(i=0;i<strlen(tmpbuf);i+=3)
		{

				tmp[0] = tmpbuf[i];
				tmp[1] = tmpbuf[i+1];
				if(tmp[0]!='0'&&tmp[1]!='a')
				{
						//	printf("%02x %02x\n", tmp[0], tmp[1]);
						changeData = HexStrValue(tmp);
						message[index++]=changeData;
				}
		}
		message[index++]=0x00;

		//手机号
		for(i = 0;i < 6;i++)
		{
				//	printf("%02x\n", tmpbuf2[i]);
				message[index++]=tmpbuf2[i];

		}
		message[index++]=0x00;


		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//加群退群
int Add_or_retreat(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=700;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//加群1,退群0
		printf("Additive group 1,Withdraw from a group 0\n");
		unsigned char x[2];		
		fgets(x,2,stdin);
		setbuf(stdin, NULL);
		count += strlen(x);

		//群ID
		printf("Please enter the group ID\n");
		unsigned char group[7];		
		fgets(group,7,stdin);
		//setbuf(stdin, NULL);
		char ch;while((ch=getchar())!='\n'&&ch!=EOF);
		count += strlen(group);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

			
		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}
	
		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//加群退群
		for(int k=0;k<1;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=x[k];
		}
		message[index++]=0x00;

		//群ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=group[k];

		}	


		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//客户端通用应答
int ClientGeneral_Answer(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=1;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//结果
		printf("0 or 1 or 2 or 3\n");
		unsigned char x[2];		
		fgets(x,2,stdin);
		setbuf(stdin, NULL);
		count += strlen(x);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}



		
		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}

		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//应答流水号
		message[index++]=0x00;
		message[index++]=0x00;

		//应答ID
		long m=0;
		DecToBCD(0, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//结果
		for(int k=0;k<1;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=x[k];
		}


		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//客户端聊天
int Client_Chat(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=7;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}

		//单聊0,群聊1
		printf("Single chat 0,Group chat 1\n");
		unsigned char x[2];		
		fgets(x,2,stdin);
		setbuf(stdin, NULL);
		count += strlen(x);

		//ID
		printf("Group ID or user ID\n");
		unsigned char id[7];		
		fgets(id,7,stdin);
		char ch;while((ch=getchar())!='\n'&&ch!=EOF);
		count += strlen(id);

		//实际内容
		unsigned char content[521]="";
		printf("Please enter the chat content(English)\n");
		fgets(content,521,stdin);
		setbuf(stdin, NULL);
		count+=strlen(content);
		Change(tmpbuf,content);


		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

			
		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}
	
		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;

		//单聊群聊
		for(int k=0;k<1;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=x[k];
		}
		

		//群ID或用户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=id[k];

		}

		//实际内容
		for(i=0;i<strlen(tmpbuf);i+=3)
		{

				tmp[0] = tmpbuf[i];
				tmp[1] = tmpbuf[i+1];
				if(tmp[0]!='0'&&tmp[1]!='a')
				{
						//	printf("%02x %02x\n", tmp[0], tmp[1]);
						changeData = HexStrValue(tmp);
						message[index++]=changeData;
				}
		}
		message[index++]=0x00;

		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
//添加好友应答
int AddFriend_Response(unsigned char *msg, int *length)
{
		unsigned char number[12]="";
		unsigned char tmpbuf[1024]="",tmpbuf1[1024]="";
		unsigned char tmpbuf2[1024]="",tmpbuf3[1024]="",tmpbuf4[1024]="";
		int index=0;
		long count=0;
		int i;
		unsigned char tmp[2] = "",tmp1[2]="";
		int changeData = 0;
		int j = 0;

		//标识位
		message[index++]=0x7E;

		unsigned char buf1[12]="";
		long n=106;

		//消息id
		DecToBCD(n, buf1, 2);
		for(int k=0;k<2;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=buf1[k];

		}


		//对方ID
		printf("Opposite party ID\n");
		unsigned char other[7];		
		fgets(other,7,stdin);
		setbuf(stdin, NULL);
		count += strlen(other);

		//消息长度
		DecToHex(count, tmpbuf3, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf3[i];
		}

			
		//账户ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=account[k];

		}
	
		//流水号
		DecToHex(Serial_number, tmpbuf4, 2);
		for(i=0;i<2;i++)
		{
				//	printf("%02x",tmpbuf3[i]);
				message[index++]=tmpbuf4[i];
		}
		Serial_number++;


		//对方ID
		for(int k=0;k<6;k++)
		{
				//printf("%02x\n",buf1[k]);
				message[index++]=other[k];

		}	


		//校验位
		message[index++]=GetCRCSum(message, index);

		//标识位
		message[index++]=0x7E;

		for(i=0;i<index;i++)
		{
				printf("%02x",message[i]);
		}
		*length = index;
		memcpy(msg, message, index);

		return 0;
}
